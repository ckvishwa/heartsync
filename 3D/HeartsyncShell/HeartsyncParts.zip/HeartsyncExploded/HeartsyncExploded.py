"""
HeartsyncShell - Fusion 360 script (Python)

Builds the heartsync enclosure as two bodies:
  - tray : 152 x 72.5 mm footprint, hollow, open at the back, display window
           + decorative ring groove + touch-strip groove cut in the front wall
  - lid  : flat back cover (the Qi2 coil sits behind/inside this side)

(Stack and Exploded versions differ only in EXPLODE.)
Run: Utilities > Add-Ins > Scripts and Add-Ins > green "+" next to "My Scripts"
     > pick the folder "HeartsyncShell" > select it > Run.

Change DISPLAY below to switch layouts. All sizes are in mm.
Axes: X = 152 mm length, Y = 72.5 mm width, Z = thickness. Front face is +Z.
"""
import adsk.core
import adsk.fusion
import traceback

# ----------------------------------------------------------------------
# SETTINGS (mm)
# ----------------------------------------------------------------------
DISPLAY = "2.7"          # "2.7", "3.12", or "3.12x2"

LENGTH = 152.0           # ASUS 180W brick footprint
WIDTH = 72.5
THICKNESS = 31.0         # total tray + lid (brick is 23, our estimate is ~31)
WALL = 2.2               # side walls and front wall
LID = 2.2                # back cover thickness
CORNER_R = 6.0           # vertical corner radius

RING_DIA = 56.0          # Qi2 ring (decorative groove on the front)
RING_GROOVE_W = 1.0
RING_GROOVE_DEPTH = 0.6
STRIP_LEN = 40.0         # touch strip marker slot
STRIP_W = 5.0
STRIP_DEPTH = 0.6

# Display windows: (width, height, centre_x, centre_y) measured from the
# centre of the front face. +X = right, +Y = toward the top edge.
if DISPLAY == "2.7":
    # lit 61.4 x 30.7 mm, window a little bigger
    WINDOWS = [(63.0, 32.0, -34.5, 0.0)]
    RING_CX = 43.0
    STRIP_CX, STRIP_CY = -34.5, 28.0
elif DISPLAY == "3.12":
    # NHD-3.12-25664UCW2 viewing area 82 x 22 mm (module body 89.2 x 44 hides inside)
    WINDOWS = [(82.0, 22.0, -27.0, 0.0)]
    RING_CX = 46.0
    STRIP_CX, STRIP_CY = -27.0, 28.0
elif DISPLAY == "3.12x2":
    WINDOWS = [(82.0, 22.0, -27.0, 13.0), (82.0, 22.0, -27.0, -13.0)]
    RING_CX = 46.0
    STRIP_CX, STRIP_CY = -27.0, 31.0
else:
    raise ValueError("DISPLAY must be '2.7', '3.12' or '3.12x2'")

# ----------------------------------------------------------------------
# PARTS AND EXPLODED VIEW
# ----------------------------------------------------------------------
PARTS = True
EXPLODE = True          # True = exploded view (layers pulled apart), False = normal stack
EXPLODE_GAP = 20.0       # mm between layers in the exploded view
SWELL = 1.2              # mm allowance above the 12 mm LiPo for cell swelling (~10%)

CELL = (100.0, 60.0, 12.0)       # 906090 LiPo, 10,000 mAh
COIL_DIA, COIL_T = 56.0, 4.5     # Qi2 coil + magnets
PCB = (70.0, 45.0, 6.0)          # main ESP32-S3 board with parts on it
SPK_DIA, SPK_T = 28.0, 8.0       # one 28 mm speaker
BACKUP = (40.0, 30.0, 5.0)       # 500 mAh backup cell (503040)
PD_BOARD = (35.0, 25.0, 4.0)     # IP5328P power bank / USB-C PD board
SIM_BOARD = (30.0, 25.0, 4.0)    # SIM7080G LTE-M + GNSS module board
GPS_PATCH = (18.0, 18.0, 4.0)    # GNSS patch antenna (faces the front)
LTE_ANT = (40.0, 8.0, 1.0)       # flex LTE-M antenna
LRA_DIA, LRA_T = 10.0, 3.5       # haptic motor (DRV2605L driver is on the PCB)
MIC = (10.0, 10.0, 3.0)          # INMP441 breakout
STRIP_PCB = (40.0, 5.0, 1.6)     # capacitive touch strip PCB
if DISPLAY == "2.7":
    MODULE = (73.0, 41.9, 3.0)   # bare glass; thickness is a guess
else:
    MODULE = (89.2, 44.0, 6.0)   # NHD-3.12-25664UCW2 body

MM = 0.1  # Fusion works in cm internally


def mm(v):
    return v * MM


def vi(v_mm):
    return adsk.core.ValueInput.createByReal(mm(v_mm))


def pt(x, y, z=0.0):
    return adsk.core.Point3D.create(mm(x), mm(y), mm(z))


def fillet_vertical_edges(comp, body, radius_mm):
    edges = adsk.core.ObjectCollection.create()
    for e in body.edges:
        g = e.geometry
        if isinstance(g, adsk.core.Line3D):
            d = g.startPoint.vectorTo(g.endPoint)
            d.normalize()
            if abs(d.z) > 0.99:
                edges.add(e)
    if edges.count == 0:
        return
    fi = comp.features.filletFeatures
    inp = fi.createInput()
    inp.addConstantRadiusEdgeSet(edges, vi(radius_mm), True)
    fi.add(inp)


def rect_sketch(comp, plane, cx, cy, w, h):
    sk = comp.sketches.add(plane)
    sk.sketchCurves.sketchLines.addCenterPointRectangle(
        adsk.core.Point3D.create(mm(cx), mm(cy), 0),
        adsk.core.Point3D.create(mm(cx + w / 2.0), mm(cy + h / 2.0), 0),
    )
    return sk


def cut_down(comp, profile, depth_mm):
    """Cut from the sketch plane downward (-Z) by depth_mm."""
    ei = comp.features.extrudeFeatures.createInput(
        profile, adsk.fusion.FeatureOperations.CutFeatureOperation)
    dist = adsk.fusion.DistanceExtentDefinition.create(vi(depth_mm))
    ei.setOneSideExtent(dist, adsk.fusion.ExtentDirections.NegativeExtentDirection)
    comp.features.extrudeFeatures.add(ei)


def plane_at(comp, z_mm):
    xy = comp.xYConstructionPlane
    if abs(z_mm) < 1e-6:
        return xy
    pi = comp.constructionPlanes.createInput()
    pi.setByOffset(xy, vi(z_mm))
    return comp.constructionPlanes.add(pi)


def shift(layer):
    """Exploded view: layer 1 is closest to the front, 5 is the lid."""
    return -EXPLODE_GAP * layer if EXPLODE else 0.0


def add_block(comp, name, layer, cx, cy, z0, size):
    w, h, t = size
    sk = rect_sketch(comp, plane_at(comp, z0 + shift(layer)), cx, cy, w, h)
    ei = comp.features.extrudeFeatures.createInput(
        sk.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
    ei.setDistanceExtent(False, vi(t))
    b = comp.features.extrudeFeatures.add(ei).bodies.item(0)
    b.name = name
    return b


def add_cyl(comp, name, layer, cx, cy, z0, dia, t):
    sk = comp.sketches.add(plane_at(comp, z0 + shift(layer)))
    sk.sketchCurves.sketchCircles.addByCenterRadius(pt(cx, cy), mm(dia / 2.0))
    ei = comp.features.extrudeFeatures.createInput(
        sk.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
    ei.setDistanceExtent(False, vi(t))
    b = comp.features.extrudeFeatures.add(ei).bodies.item(0)
    b.name = name
    return b


def build_parts(design, comp, tray, lid, inner_top):
    """All internal parts. z = 0 is the back of the tray, inner_top the inside of the front wall."""
    parts = []
    cell_cx = -LENGTH / 2.0 + WALL + 2.0 + CELL[0] / 2.0
    spk_cx = cell_cx + CELL[0] / 2.0 + 4.0 + SPK_DIA / 2.0
    z_cell = COIL_T
    above_cell = COIL_T + CELL[2] + SWELL     # PCB and friends sit above the cell + swell gap
    z_beside = COIL_T + SPK_T + 0.5           # boards above the speaker

    # layer 4: coil
    parts.append(add_cyl(comp, "part_qi2_coil", 4, RING_CX, 0, 0, COIL_DIA, COIL_T))
    # layer 3: power layer
    parts.append(add_block(comp, "part_cell_10000mAh", 3, cell_cx, 0, z_cell, CELL))
    parts.append(add_cyl(comp, "part_speaker", 3, spk_cx, 0, z_cell, SPK_DIA, SPK_T))
    parts.append(add_block(comp, "part_backup_cell_500mAh", 3, 50, 9, z_beside, BACKUP))
    parts.append(add_block(comp, "part_pd_board", 3, 51, -20.5, z_beside, PD_BOARD))
    # layer 2: electronics
    parts.append(add_block(comp, "part_main_pcb", 2, -34.5, 0, above_cell, PCB))
    parts.append(add_block(comp, "part_sim7080g", 2, 17, -20, above_cell, SIM_BOARD))
    parts.append(add_cyl(comp, "part_haptic_lra", 2, 17, 28, above_cell, LRA_DIA, LRA_T))
    # layer 1: against the front wall
    for i, (w, h, cx, cy) in enumerate(WINDOWS):
        parts.append(add_block(comp, "part_display_%d" % (i + 1), 1, cx, cy,
                               inner_top - MODULE[2], MODULE))
    parts.append(add_block(comp, "part_touch_strip_pcb", 1, STRIP_CX, STRIP_CY,
                           inner_top - STRIP_PCB[2], STRIP_PCB))
    parts.append(add_block(comp, "part_mic", 1, -64, 28.5, inner_top - MIC[2], MIC))
    parts.append(add_block(comp, "part_gps_patch", 1, 17, 5, inner_top - GPS_PATCH[2], GPS_PATCH))
    parts.append(add_block(comp, "part_lte_antenna", 1, 50, 29, inner_top - LTE_ANT[2], LTE_ANT))

    if EXPLODE:
        return "Exploded view: layers %.0f mm apart (front group, electronics, power, coil, lid)." % EXPLODE_GAP

    stack = COIL_T + CELL[2] + SWELL + PCB[2] + MODULE[2]
    spare = inner_top - stack
    ents = adsk.core.ObjectCollection.create()
    for b in parts + [tray, lid]:
        ents.add(b)
    res = design.analyzeInterference(design.createInterferenceInput(ents))
    lines = []
    for i in range(res.count):
        r = res.item(i)
        lines.append("%s  x  %s  (%.1f mm3)" % (
            r.entityOne.name, r.entityTwo.name, r.interferenceBody.volume * 1000.0))
    msg = ("Tallest column: coil %.1f + cell %.1f + swell %.1f + PCB %.1f + display %.1f = %.1f mm\n"
           "Room inside = %.1f mm -> %s%.1f mm\n") % (
        COIL_T, CELL[2], SWELL, PCB[2], MODULE[2], stack, inner_top,
        "SHORT by " if spare < 0 else "spare ", abs(spare))
    if lines:
        msg += ("Interferences (%d):\n  " % res.count) + "\n  ".join(lines)
    else:
        msg += "No interferences."
    return msg


def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        design = adsk.fusion.Design.cast(app.activeProduct)
        if not design:
            ui.messageBox("Open a Design workspace first.")
            return
        comp = design.rootComponent
        xy = comp.xYConstructionPlane

        tray_h = THICKNESS - LID

        # ---------------- tray: outer block ----------------
        sk = rect_sketch(comp, xy, 0, 0, LENGTH, WIDTH)
        ei = comp.features.extrudeFeatures.createInput(
            sk.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
        ei.setDistanceExtent(False, vi(tray_h))
        tray_feat = comp.features.extrudeFeatures.add(ei)
        tray = tray_feat.bodies.item(0)
        tray.name = "heartsync_tray"
        fillet_vertical_edges(comp, tray, CORNER_R)

        # ---------------- shell: open the back (lowest planar face) ----------------
        back = None
        for f in tray.faces:
            if isinstance(f.geometry, adsk.core.Plane):
                n = f.geometry.normal
                if abs(n.z) > 0.99:
                    if back is None or f.centroid.z < back.centroid.z:
                        back = f
        faces = adsk.core.ObjectCollection.create()
        faces.add(back)
        si = comp.features.shellFeatures.createInput(faces)
        si.insideThickness = vi(WALL)
        comp.features.shellFeatures.add(si)

        # ---------------- front-face plane ----------------
        pi = comp.constructionPlanes.createInput()
        pi.setByOffset(xy, vi(tray_h))
        front = comp.constructionPlanes.add(pi)
        front.name = "front_face"

        # ---------------- display windows (through the front wall) ----------------
        for (w, h, cx, cy) in WINDOWS:
            s = rect_sketch(comp, front, cx, cy, w, h)
            cut_down(comp, s.profiles.item(0), WALL * 1.5)

        # ---------------- decorative ring groove ----------------
        s = comp.sketches.add(front)
        c = s.sketchCurves.sketchCircles
        c.addByCenterRadius(pt(RING_CX, 0), mm(RING_DIA / 2.0))
        c.addByCenterRadius(pt(RING_CX, 0), mm(RING_DIA / 2.0 - RING_GROOVE_W))
        annulus = None
        for p in s.profiles:
            a = p.areaProperties().area
            if annulus is None or a < annulus[0]:
                annulus = (a, p)
        cut_down(comp, annulus[1], RING_GROOVE_DEPTH)

        # ---------------- touch strip marker ----------------
        s = rect_sketch(comp, front, STRIP_CX, STRIP_CY, STRIP_LEN, STRIP_W)
        cut_down(comp, s.profiles.item(0), STRIP_DEPTH)

        # ---------------- lid (new body, sits below the tray) ----------------
        sk = rect_sketch(comp, plane_at(comp, shift(5)), 0, 0, LENGTH, WIDTH)
        ei = comp.features.extrudeFeatures.createInput(
            sk.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
        ei.setOneSideExtent(
            adsk.fusion.DistanceExtentDefinition.create(vi(LID)),
            adsk.fusion.ExtentDirections.NegativeExtentDirection)
        lid = comp.features.extrudeFeatures.add(ei).bodies.item(0)
        lid.name = "heartsync_lid"
        fillet_vertical_edges(comp, lid, CORNER_R)

        report = ""
        if PARTS:
            report = "\n\n" + build_parts(design, comp, tray, lid, tray_h - WALL)

        app.activeViewport.fit()
        ui.messageBox(
            "heartsync shell built (%s display).\n"
            "Tray %.1f x %.1f x %.1f mm + lid %.1f mm = %.1f mm thick.%s"
            % (DISPLAY, LENGTH, WIDTH, tray_h, LID, THICKNESS, report))

    except Exception:
        if ui:
            ui.messageBox("Failed:\n{}".format(traceback.format_exc()))
