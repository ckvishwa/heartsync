"""
heartsync carrier v0.1 - board setup for the KiCad PCB editor (KiCad 8/9/10)

Use AFTER importing heartsync_carrier.net (File > Import > Netlist).
Run in the PCB editor: Tools > Scripting Console, then:
    exec(open(r"D:\\SyncD\\hardware\\kicad\\place_board.py").read())

It does:
  1. draws the 70 x 45 mm board outline (Edge.Cuts)
  2. adds four M2 mounting holes
  3. places every part in its area (connectors on the edges, ESP32 antenna on the top edge)
  4. adds an antenna keepout under the ESP32 antenna
  5. adds GND copper pours on both layers and fills them
It does NOT route tracks. Route by hand (or with the Freerouting plugin), then run DRC.
Each step is separate: if one fails, the console says which and the rest still run.
"""
import os
import pcbnew

X0, Y0 = 100.0, 100.0          # board top-left corner in the editor (mm)
W, H = 70.0, 45.0

board = pcbnew.GetBoard()
report = []


def mm(v):
    return pcbnew.FromMM(v)


def pt(x, y):
    return pcbnew.VECTOR2I(mm(X0 + x), mm(Y0 + y))


def step(name, fn):
    try:
        fn()
        report.append("ok    " + name)
    except Exception as e:  # keep going, report at the end
        report.append("FAIL  %s: %s" % (name, e))


# ------------------------------------------------------------------ 1. outline
def outline():
    s = pcbnew.PCB_SHAPE(board)
    s.SetShape(pcbnew.SHAPE_T_RECT)
    s.SetStart(pt(0, 0))
    s.SetEnd(pt(W, H))
    s.SetLayer(pcbnew.Edge_Cuts)
    s.SetWidth(mm(0.1))
    board.Add(s)


# ------------------------------------------------------------------ 2. mounting holes
def holes():
    lib = None
    for var in ("KICAD10_FOOTPRINT_DIR", "KICAD9_FOOTPRINT_DIR", "KICAD8_FOOTPRINT_DIR", "KICAD_FOOTPRINT_DIR"):
        d = os.environ.get(var)
        if d and os.path.isdir(os.path.join(d, "MountingHole.pretty")):
            lib = os.path.join(d, "MountingHole.pretty")
            break
    if not lib:
        raise RuntimeError("footprint folder not found; add 4x MountingHole_2.2mm_M2 by hand")
    for i, (x, y) in enumerate(((3.0, 3.0), (3.0, 26.0), (45.5, 14.0), (48.5, 42.0))):
        fp = pcbnew.FootprintLoad(lib, "MountingHole_2.2mm_M2")
        fp.SetReference("H%d" % (i + 1))
        fp.SetPosition(pt(x, y))
        board.Add(fp)


# ------------------------------------------------------------------ 3. placement
# (ref, x, y, rotation) in mm from the board top-left corner. Passives sit next to their chip.
PLACE = [
    # ESP32-S3 module: body top edge on the board top edge, antenna over the edge
    ("U1", 15.5, 12.75, 0),
    # 3.3 V buck, bottom-left
    ("U2", 6.0, 33.0, 0), ("L1", 11.5, 33.0, 0), ("C4", 3.0, 30.0, 90), ("C5", 15.5, 30.0, 90),
    ("R3", 6.0, 36.5, 0), ("R4", 9.5, 36.5, 0), ("C1", 27.5, 22.0, 90), ("C2", 27.5, 18.5, 90),
    ("R1", 25.5, 27.0, 0), ("C3", 25.5, 29.5, 0), ("R2", 25.5, 32.0, 0),
    ("SW1", 30.5, 35.5, 0), ("SW2", 37.0, 35.5, 0),
    # power connector + ESD + bulk, right edge
    ("J1", 66.0, 15.0, 90), ("U3", 58.5, 15.0, 0), ("C6", 58.5, 19.0, 0),
    # SIM level shifter + PWRKEY, top-right near J3
    ("J3", 66.0, 4.5, 90), ("U9", 56.5, 5.0, 0), ("C16", 56.5, 8.0, 0), ("C17", 53.0, 5.0, 90),
    ("Q1", 60.5, 9.0, 0), ("R11", 56.5, 10.5, 0), ("R12", 60.5, 12.0, 0),
    # amps, right side near the speaker connectors
    ("U4", 52.0, 21.5, 0), ("C7", 47.5, 21.5, 90), ("C8", 52.0, 18.5, 0), ("R5", 48.5, 25.0, 0),
    ("U5", 52.0, 28.5, 0), ("C9", 47.5, 28.5, 90), ("C10", 52.0, 31.5, 0), ("R6", 48.5, 32.0, 0),
    ("R7", 48.5, 34.0, 0),
    ("J4", 66.0, 24.0, 90), ("J5", 66.0, 30.0, 90),
    # haptic driver near J6
    ("U6", 55.0, 37.0, 0), ("C11", 55.0, 40.0, 0), ("C12", 51.5, 37.0, 90), ("J6", 66.0, 36.0, 90),
    # fuel gauge near the battery connector
    ("U8", 59.0, 42.0, 0), ("C15", 55.5, 42.5, 0), ("J2", 66.0, 41.5, 90),
    # IMU, middle of the board (away from edges, flex and heat)
    ("U7", 36.0, 24.0, 0), ("C13", 36.0, 27.0, 0), ("C14", 39.5, 24.0, 90),
    # I2C / alert / button / mute resistors
    ("R8", 40.0, 18.0, 0), ("R9", 40.0, 20.0, 0), ("R10", 43.5, 18.0, 0),
    ("R13", 43.5, 9.0, 0), ("R14", 43.5, 11.0, 0), ("C18", 47.0, 9.0, 0),
    ("R15", 30.0, 30.0, 0), ("R16", 33.5, 30.0, 0), ("C19", 37.0, 30.0, 0),
    # top edge connectors (right of the antenna keepout)
    ("J7", 36.0, 3.5, 180), ("J8", 45.0, 3.5, 180), ("J9", 52.0, 13.5, 180),
    # bottom edge connectors
    ("J11", 18.0, 41.5, 0), ("J10", 30.5, 42.0, 0), ("J12", 41.0, 42.0, 0),
    # test points, bottom-left corner strip
    ("TP1", 2.5, 39.0, 0), ("TP2", 5.0, 39.0, 0), ("TP3", 7.5, 39.0, 0), ("TP4", 10.0, 39.0, 0),
    ("TP5", 2.5, 42.5, 0), ("TP6", 5.0, 42.5, 0), ("TP7", 7.5, 42.5, 0),
]


def place():
    missing = []
    for ref, x, y, rot in PLACE:
        fp = board.FindFootprintByReference(ref)
        if fp is None:
            missing.append(ref)
            continue
        fp.SetPosition(pt(x, y))
        fp.SetOrientationDegrees(rot)
    if missing:
        raise RuntimeError("not on the board (import the netlist first?): " + ", ".join(missing))


# ------------------------------------------------------------------ 4. antenna keepout
def keepout():
    z = pcbnew.ZONE(board)
    z.SetIsRuleArea(True)
    z.SetDoNotAllowCopperPour(True)
    z.SetDoNotAllowTracks(True)
    z.SetDoNotAllowVias(True)
    z.SetDoNotAllowPads(False)
    z.SetLayerSet(pcbnew.LSET.AllCuMask())
    o = z.Outline()
    o.NewOutline()
    for x, y in ((4.0, 0.0), (27.0, 0.0), (27.0, 7.0), (4.0, 7.0)):
        o.Append(mm(X0 + x), mm(Y0 + y))
    z.SetZoneName("ESP32 antenna keepout")
    board.Add(z)


# ------------------------------------------------------------------ 5. GND pours
def pours():
    gnd = board.FindNet("GND")
    if gnd is None:
        raise RuntimeError("no GND net (import the netlist first)")
    for layer in (pcbnew.F_Cu, pcbnew.B_Cu):
        z = pcbnew.ZONE(board)
        z.SetLayer(layer)
        z.SetNet(gnd)
        z.SetLocalClearance(mm(0.3))
        z.SetMinThickness(mm(0.25))
        o = z.Outline()
        o.NewOutline()
        for x, y in ((0.3, 0.3), (W - 0.3, 0.3), (W - 0.3, H - 0.3), (0.3, H - 0.3)):
            o.Append(mm(X0 + x), mm(Y0 + y))
        board.Add(z)
    pcbnew.ZONE_FILLER(board).Fill(board.Zones())


step("board outline 70 x 45 mm", outline)
step("M2 mounting holes", holes)
step("place parts", place)
step("antenna keepout", keepout)
step("GND pours (both layers)", pours)
pcbnew.Refresh()
print("\n".join(report))
print("Next: route, then Inspect > Design Rules Checker.")
