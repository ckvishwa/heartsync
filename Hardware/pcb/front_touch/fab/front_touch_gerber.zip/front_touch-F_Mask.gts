%TF.GenerationSoftware,KiCad,Pcbnew,10.0.8*%
%TF.CreationDate,2026-11-23T15:24:13-05:00*%
%TF.ProjectId,front_touch,66726f6e-745f-4746-9f75-63682e6b6963,A*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.8) date 2026-11-23 15:24:13*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,1.000000*%
G04 APERTURE END LIST*
D10*
%TO.C,TP1*%
X82500000Y-70250000D03*
%TD*%
M02*
